# pull all images
docker pull nanofab/nemo:1.12.0
docker pull nanofab/nginx:2.1.0
docker pull nanofab/control_center:2.3.0

# create and migtrate nemo db
docker run --interactive --tty --volume ${pwd}/nemo:/nemo nanofab/nemo:1.12.0 django-admin migrate
# collect nemo static files
docker run --interactive --tty --volume ${pwd}/nemo:/nemo nanofab/nemo:1.12.0 django-admin collectstatic --no-input --clear
# copy splash_pad data
docker run --interactive --tty --volume ${pwd}/nemo:/nemo nanofab/nemo:1.12.0 django-admin loaddata /nemo/splash_pad.json

# set setting for Windows Host
Add-Content control_center\settings.py "WINDOWS_HOST = True"

# start control-center
docker run --publish 8001:8000 --name control-center --volume /var/run/docker.sock:/var/run/docker.sock --volume ${pwd}:/control-center/compose/nemo-compose --volume ${pwd}/control_center:/control-center/config --detach nanofab/control_center:2.3.0

# wait for db to be populated
DO
{
  Start-Sleep -Seconds 1.5
} UNTIL (Test-Path control_center/control_center.sqlite3 -PathType Leaf)

docker exec --interactive --tty control-center django-admin loaddata /control-center/config/user.json

(Get-Content docker-compose.template).replace('$COMPOSE_PWD', $(pwd)) | Set-Content docker-compose.yml

# create everything
docker exec --interactive --tty --workdir /control-center/compose/nemo-compose --env COMPOSE_FORCE_WINDOWS_HOST=1 --env COMPOSE_CONVERT_WINDOWS_PATHS=1 control-center docker-compose up --detach
"go to htpp://localhost:8001 to manage docker containers (username: 'captain', password: 'qwertyuiop[]\') and http://localhost to launch NEMO"
Start-Sleep -Seconds 30
