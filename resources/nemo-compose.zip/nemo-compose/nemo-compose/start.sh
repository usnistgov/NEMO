#!/bin/bash

# Exit if any of following commands fails
set -e

# pull all images
docker pull nanofab/nemo:1.12.0
docker pull nanofab/nginx:2.1.0
docker pull nanofab/control_center:2.3.0

# create and migtrate nemo db
docker run --interactive --tty --volume $(pwd)/nemo:/nemo nanofab/nemo:1.12.0 django-admin migrate
# collect nemo static files
docker run --interactive --tty --volume $(pwd)/nemo:/nemo nanofab/nemo:1.12.0 django-admin collectstatic --no-input --clear
# copy splash_pad data
docker run --interactive --tty --volume $(pwd)/nemo:/nemo nanofab/nemo:1.12.0 django-admin loaddata /nemo/splash_pad.json

# start control-center
docker run --publish 8001:8000 --name control-center --volume /var/run/docker.sock:/var/run/docker.sock --volume $(pwd):$(pwd) --volume $(pwd)/control_center:/control-center/config --workdir $(pwd) --env DOCKER_COMPOSE_YML_PATH=$(pwd)/docker-compose.yml --detach nanofab/control_center:2.3.0

#wait for db to be populated
until [ -f ./control_center/control_center.sqlite3 ]
do
     sleep 5
done
docker exec --interactive --tty control-center django-admin loaddata /control-center/config/user.json

sed "s|\$COMPOSE_PWD|$(pwd)|g" docker-compose.template > docker-compose.yml

# create everything
docker exec --interactive --tty control-center docker-compose up --detach
echo "go to htpp://localhost:8001 to manage docker containers (username: 'captain', password: 'qwertyuiop[]\') and http://localhost to launch NEMO"
