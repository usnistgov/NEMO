ALLOWED_HOSTS = ['*']

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'test'
CSRF_COOKIE_SECURE = False
WINDOWS_HOST = True
